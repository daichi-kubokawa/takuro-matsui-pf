import Link from "next/link";
import { getWorkDetail } from "../../lib/microcms/works";

export default async function OriginalDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: { from?: string };
}) {
  // ✅ Next.js 15 対応
  const { id } = await params;

  const work = await getWorkDetail(id);
  const from = searchParams.from ?? "/";

  const images = work.images?.length
    ? work.images
    : work.thumbnail
      ? [work.thumbnail]
      : [];

  return (
    <main className="px-4 md:px-12 py-14">
      <Link
        href={from}
        className="mb-6 inline-block opacity-70 hover:opacity-100"
      >
        ← Back
      </Link>

      <div className="space-y-6">
        {images.map((img, i) => (
          <img key={i} src={img.url} alt="" className="w-full h-auto block" />
        ))}
      </div>
    </main>
  );
}

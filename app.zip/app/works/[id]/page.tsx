import Link from "next/link";
import { getWorksMerged } from "../lib/microcms/works";

export default async function WorksPage() {
  const { works } = await getWorksMerged({ kind: "works" });

  return (
    <main className="px-4 sm:px-6">
      <div className="mt-8 columns-2 sm:columns-3 lg:columns-4 gap-4">
        {works.map((work) => (
          <Link
            key={work.id}
            href={`/works/${work.id}?from=/works&modal=1`}
            className="mb-4 block break-inside-avoid"
          >
            <img src={work.thumbnail.url} alt="" className="w-full h-auto" />
          </Link>
        ))}
      </div>
    </main>
  );
}

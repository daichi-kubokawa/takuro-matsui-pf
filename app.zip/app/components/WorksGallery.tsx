// app/components/WorksGallery.tsx
"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import type { Tag, Work } from "../lib/microcms/types";

type LinkMode = "byKind" | "fixedWorks" | "fixedOriginal";

type Props = {
  works: Work[];
  tags: Tag[];
  /**
   * byKind: kind に応じて /works/[id] or /original/[id]
   * fixedWorks: 常に /works/[id]
   * fixedOriginal: 常に /original/[id]
   */
  linkMode?: LinkMode;
};

function normalizeKind(kind: unknown): "works" | "original" | "unknown" {
  if (typeof kind !== "string") return "unknown";
  const k = kind.toLowerCase();
  if (k === "works") return "works";
  if (k === "original") return "original";
  return "unknown";
}

function hrefFor(work: Work, linkMode: LinkMode) {
  if (linkMode === "fixedWorks") return `/works/${work.id}`;
  if (linkMode === "fixedOriginal") return `/original/${work.id}`;

  const kind = normalizeKind((work as any).kind);
  if (kind === "original") return `/original/${work.id}`;
  // unknown は works 扱い（既存運用に合わせる）
  return `/works/${work.id}`;
}

export default function WorksGallery({ works, tags, linkMode = "byKind" }: Props) {
  // ✅ 複数選択フィルター（All は「未選択 = 全件表示」）
  const [selectedTagIds, setSelectedTagIds] = useState<string[]>([]);

  const activeTags = useMemo(() => {
    // microCMS 側の isActive / order がある場合でも壊れないように
    const t = [...(tags ?? [])].filter((x) => (x as any).isActive !== false);
    t.sort((a, b) => ((a as any).order ?? 9999) - ((b as any).order ?? 9999));
    return t;
  }, [tags]);

  const filteredWorks = useMemo(() => {
    if (!selectedTagIds.length) return works;

    const sel = new Set(selectedTagIds);
    return works.filter((w) => {
      const wTags = (w.tags ?? []).map((t) => t.id);
      return wTags.some((id) => sel.has(id));
    });
  }, [works, selectedTagIds]);

  return (
    <section>
      {/* Filters */}
      <div className="mb-10 flex flex-wrap items-center gap-4">
        <button
          type="button"
          onClick={() => setSelectedTagIds([])}
          aria-pressed={selectedTagIds.length === 0}
          className={
            selectedTagIds.length === 0
              ? "font-semibold underline underline-offset-4"
              : "opacity-70 hover:opacity-100"
          }
        >
          All
        </button>

        {activeTags.map((tag) => {
          const on = selectedTagIds.includes(tag.id);
          return (
            <button
              key={tag.id}
              type="button"
              onClick={() =>
                setSelectedTagIds((prev) =>
                  on ? prev.filter((id) => id !== tag.id) : [...prev, tag.id],
                )
              }
              aria-pressed={on}
              className={
                on
                  ? "font-semibold underline underline-offset-4"
                  : "opacity-70 hover:opacity-100"
              }
            >
              {tag.name}
            </button>
          );
        })}
      </div>

      {/* Masonry (Pinterest-like) */}
      <div className="columns-2 md:columns-3 lg:columns-4 [column-gap:24px]">
        {filteredWorks.map((work) => {
          const src = work.thumbnail?.url ?? work.images?.[0]?.url;
          if (!src) return null;

          const href = hrefFor(work, linkMode);

          return (
            <Link
              key={work.id}
              href={href}
              className="mb-6 block [break-inside:avoid] focus:outline-none"
            >
              <div className="will-change-transform transition-transform duration-300 ease-out hover:-translate-y-1">
                <img
                  src={src}
                  alt={work.title ?? ""}
                  className="block h-auto w-full"
                  loading="lazy"
                />
              </div>
            </Link>
          );
        })}
      </div>
    </section>
  );
}

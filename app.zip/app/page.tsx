import Link from "next/link";
import { getWorksMerged } from "./lib/microcms/works";

export default async function Page() {
  const { works } = await getWorksMerged();

  return (
    <main className="px-4 sm:px-6">
      <div className="mt-8">
        <div className="columns-2 sm:columns-3 lg:columns-4 gap-4">
          {works.map((work) => {
            const href =
              work.kind === "works"
                ? `/works/${work.id}?from=/&modal=1`
                : `/original/${work.id}?from=/&modal=1`;

            return (
              <Link
                key={work.id}
                href={href}
                className="mb-4 block break-inside-avoid"
              >
                <img
                  src={work.thumbnail.url}
                  alt=""
                  className="w-full h-auto"
                />
              </Link>
            );
          })}
        </div>
      </div>
    </main>
  );
}

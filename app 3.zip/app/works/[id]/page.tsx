import Link from "next/link";
import { getWorkDetail } from "../../lib/microcms/works";

export default async function WorkDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ from?: string }>;
}) {
  // Next.js 15 対応（重要）
  const { id } = await params;
  const { from } = await searchParams;

  const work = await getWorkDetail(id);
  const backTo = from ?? "/";

  const images = work.images?.length
    ? work.images
    : work.thumbnail
      ? [work.thumbnail]
      : [];

  return (
    <main className="px-4 md:px-12 py-14">
      {/* Back */}
      <Link
        href={backTo}
        className="mb-8 inline-block text-sm opacity-70 hover:opacity-100"
      >
        ← Back
      </Link>

      {/* Title & Credit（WORKSのみ表示） */}
      <div className="mb-12 space-y-4">
        {work.title && (
          <h1 className="text-[18px] font-medium">{work.title}</h1>
        )}

        {work.credit && (
          <div
            className="text-[16px] md:text-[18px] opacity-70 leading-relaxed"
            dangerouslySetInnerHTML={{ __html: work.credit }}
          />
        )}
      </div>

      {/* Images */}
      <div className="space-y-6">
        {images.map((img, i) => (
          // eslint-disable-next-line @next/next/no-img-element
          <img key={i} src={img.url} alt="" className="w-full h-auto block" />
        ))}
      </div>
    </main>
  );
}

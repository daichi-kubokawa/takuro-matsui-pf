// app/components/WorksGallery.tsx
"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useMemo, useState } from "react";
import type { Tag, Work } from "../lib/microcms/types";

type LinkMode = "byKind" | "fixedWorks" | "fixedOriginal";

function normalizeKind(kind: unknown): "works" | "original" | "unknown" {
  if (typeof kind === "string") {
    const k = kind.trim().toLowerCase();
    if (k === "works") return "works";
    if (k === "original") return "original";
    return "unknown";
  }
  if (Array.isArray(kind)) {
    const arr = kind
      .filter((v) => typeof v === "string")
      .map((v) => v.trim().toLowerCase());
    if (arr.includes("original")) return "original";
    if (arr.includes("works")) return "works";
    return "unknown";
  }
  return "unknown";
}

export default function WorksGallery({
  works,
  tags,
  linkMode = "byKind",
}: {
  works: Work[];
  tags: Tag[];
  linkMode?: LinkMode; // ★ page.tsx 側で渡してなくても壊れない
}) {
  const pathname = usePathname();

  // 一覧ページ（/ , /works , /original）以外でも変にならないように保険
  const from = useMemo(() => {
    if (pathname === "/works") return "/works";
    if (pathname === "/original") return "/original";
    return "/"; // default: ALL
  }, [pathname]);

  const ALL_ID = "__all__";
  const [activeTagId, setActiveTagId] = useState<string>(ALL_ID);

  const tagItems = useMemo(() => {
    return [{ id: ALL_ID, name: "ALL", slug: "all" } as Tag, ...tags];
  }, [tags]);

  const filteredWorks = useMemo(() => {
    if (activeTagId === ALL_ID) return works;
    return works.filter((w) =>
      (w.tags ?? []).some((t) => t.id === activeTagId),
    );
  }, [works, activeTagId]);

  function hrefFor(w: Work) {
    // 1) 遷移先ベース（/works or /original）を決める
    let basePath: "/works" | "/original" = "/works";

    if (linkMode === "fixedWorks") basePath = "/works";
    else if (linkMode === "fixedOriginal") basePath = "/original";
    else {
      // byKind：kind を正規化して判断（ここが ALL→全部/works を潰すポイント）
      const k = normalizeKind((w as any).kind);
      basePath = k === "original" ? "/original" : "/works";
    }

    // 2) from（戻り先）を必ず付与（ここが Back で /works に戻る問題を潰すポイント）
    const qs = new URLSearchParams();
    qs.set("from", from);

    return `${basePath}/${w.id}?${qs.toString()}`;
  }

  return (
    <section>
      {/* Filters（ラベル文字は出さない） */}
      <div className="mb-8">
        <div className="flex flex-wrap gap-2">
          {tagItems.map((t) => {
            const isActive = activeTagId === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setActiveTagId(t.id)}
                className={[
                  "text-[11px] leading-none px-3 py-2 rounded-full transition",
                  isActive ? "opacity-100" : "opacity-60 hover:opacity-100",
                ].join(" ")}
              >
                {t.name}
              </button>
            );
          })}
        </div>
      </div>

      {/* Masonry */}
      <div className="masonry-grid">
        {filteredWorks.map((w) => {
          const thumb = w.thumbnail?.url ?? w.images?.[0]?.url;
          if (!thumb) return null;

          return (
            <div key={w.id} className="masonry-item">
              <Link href={hrefFor(w)} className="group block">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={thumb}
                  alt=""
                  loading="lazy"
                  className="w-full h-auto block"
                />
              </Link>
            </div>
          );
        })}
      </div>
    </section>
  );
}

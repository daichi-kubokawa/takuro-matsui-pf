"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

type Props = {
  siteTitle: string;
  contactEmail?: string | null;
};

function isActive(pathname: string, href: string) {
  // ALLは "/" のみアクティブ
  if (href === "/") return pathname === "/";

  // /works と /works/[id] もまとめてアクティブ
  if (href === "/works")
    return pathname === "/works" || pathname.startsWith("/works/");

  // /original と /original/[id] もまとめてアクティブ
  if (href === "/original")
    return pathname === "/original" || pathname.startsWith("/original/");

  // /about
  if (href === "/about") return pathname === "/about";

  return false;
}

function navClass(active: boolean) {
  return [
    "hover:opacity-60 transition-opacity",
    active ? "font-semibold underline underline-offset-4" : "font-normal",
  ].join(" ");
}

export default function Header({ siteTitle, contactEmail }: Props) {
  const pathname = usePathname();

  return (
    <header className="w-full">
      <div className="px-4 sm:px-6 py-6 flex items-center justify-between">
        {/* 左：siteTitle */}
        <Link href="/" className="text-sm sm:text-base tracking-wide">
          {siteTitle}
        </Link>

        {/* 右：メニュー */}
        <nav className="flex items-center gap-6 text-xs sm:text-sm tracking-wide">
          <Link href="/" className={navClass(isActive(pathname, "/"))}>
            ALL
          </Link>
          <Link
            href="/works"
            className={navClass(isActive(pathname, "/works"))}
          >
            WORKS
          </Link>
          <Link
            href="/original"
            className={navClass(isActive(pathname, "/original"))}
          >
            ORIGINAL
          </Link>
          <Link
            href="/about"
            className={navClass(isActive(pathname, "/about"))}
          >
            ABOUT
          </Link>

          {/* CONTACTは mailto なので active判定しない */}
          {contactEmail ? (
            <a
              href={`mailto:${contactEmail}`}
              className="hover:opacity-60 transition-opacity"
            >
              CONTACT
            </a>
          ) : (
            <span className="text-neutral-400">CONTACT</span>
          )}
        </nav>
      </div>
    </header>
  );
}
